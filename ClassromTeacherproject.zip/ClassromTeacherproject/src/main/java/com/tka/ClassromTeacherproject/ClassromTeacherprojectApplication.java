package com.tka.ClassromTeacherproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassromTeacherprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassromTeacherprojectApplication.class, args);
	}

}
